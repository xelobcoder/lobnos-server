-- =====================================================
-- PAYROLL SYSTEM DATABASE SCHEMA
-- Created: December 11, 2025
-- Database: MySQL/MariaDB
-- Total Tables: 17
-- =====================================================

-- =====================================================
-- SALARY GRADES (Must be created first due to foreign key references)
-- =====================================================

-- Salary Grades Configuration
CREATE TABLE IF NOT EXISTS `payroll_salary_grades` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `grade_name` VARCHAR(100) NOT NULL,
    `grade_level` VARCHAR(50) NOT NULL,
    `min_salary` DECIMAL(10, 2) NULL,
    `max_salary` DECIMAL(10, 2) NULL,
    `description` TEXT NULL,
    `currency` VARCHAR(3) DEFAULT 'GHS',
    `is_active` BOOLEAN DEFAULT TRUE,

    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    `created_by` INT UNSIGNED NULL,
    `updated_by` INT UNSIGNED NULL,

    FOREIGN KEY (`created_by`) REFERENCES `roles`(`employeeid`) ON DELETE SET NULL ON UPDATE CASCADE,
    FOREIGN KEY (`updated_by`) REFERENCES `roles`(`employeeid`) ON DELETE SET NULL ON UPDATE CASCADE,

    UNIQUE KEY `unique_grade_name` (`grade_name`),
    INDEX `idx_grade_level` (`grade_level`),
    INDEX `idx_is_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- EMPLOYEE COMPENSATION AND EARNINGS
-- =====================================================

-- Employee Compensation Configuration
CREATE TABLE IF NOT EXISTS `payroll_employee_compensation` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `employeeid` INT UNSIGNED NOT NULL,
    `compensation_type` ENUM('salary', 'hourly', 'commission', 'hybrid') NOT NULL,
    
    -- Salary-based
    `basic_salary` DECIMAL(10, 2) NULL,
    `salary_grade_id` INT UNSIGNED NULL,
    `currency` VARCHAR(10) DEFAULT 'GHS',
    
    -- Hourly-based
    `hourly_rate` DECIMAL(10, 2) NULL,
    `overtime_rate_multiplier` DECIMAL(3, 2) DEFAULT 1.5,
    
    -- Commission-based
    `commission_percentage` DECIMAL(5, 2) NULL,
    `commission_target` DECIMAL(10, 2) NULL,
    
    -- Payment schedule
    `payment_frequency` ENUM('monthly', 'bi-weekly', 'weekly') DEFAULT 'monthly',
    `payment_method` ENUM('bank_transfer', 'cash', 'cheque', 'mobile_money') DEFAULT 'bank_transfer',
    `bank_account_number` VARCHAR(50) NULL,
    `bank_name` VARCHAR(100) NULL,
    `bank_branch` VARCHAR(100) NULL,
    `mobile_money_number` VARCHAR(15) NULL,
    
    -- Effective dates
    `effective_from` DATE NOT NULL,
    `effective_to` DATE NULL,
    `is_active` BOOLEAN DEFAULT TRUE,
    
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    `created_by` INT UNSIGNED NULL,
    `updated_by` INT UNSIGNED NULL,
    
    FOREIGN KEY (`employeeid`) REFERENCES `roles`(`employeeid`) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (`salary_grade_id`) REFERENCES `payroll_salary_grades`(`id`) ON DELETE SET NULL ON UPDATE CASCADE,
    FOREIGN KEY (`created_by`) REFERENCES `roles`(`employeeid`) ON DELETE SET NULL ON UPDATE CASCADE,
    FOREIGN KEY (`updated_by`) REFERENCES `roles`(`employeeid`) ON DELETE SET NULL ON UPDATE CASCADE,
    
    INDEX `idx_employeeid` (`employeeid`),
    INDEX `idx_is_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================

-- =====================================================
-- ATTENDANCE AND TIME TRACKING
-- =====================================================

-- Employee Attendance
CREATE TABLE IF NOT EXISTS `payroll_employee_attendance` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `employeeid` INT UNSIGNED NOT NULL,
    `attendance_date` DATE NOT NULL,
    
    -- Clock in/out times
    `clock_in` DATETIME NULL,
    `clock_out` DATETIME NULL,
    `total_hours` DECIMAL(5, 2) NULL,
    
    -- Work type
    `shift_type` ENUM('regular', 'night', 'weekend', 'holiday') DEFAULT 'regular',
    `work_location` ENUM('on-site', 'remote', 'field') DEFAULT 'on-site',
    
    -- Status
    `status` ENUM('present', 'absent', 'half-day', 'late', 'early_departure') DEFAULT 'present',
    `late_minutes` INT DEFAULT 0,
    
    -- Overtime
    `overtime_hours` DECIMAL(5, 2) DEFAULT 0,
    `overtime_approved` BOOLEAN DEFAULT FALSE,
    `overtime_approved_by` INT UNSIGNED NULL,
    
    `remarks` TEXT NULL,
    
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (`employeeid`) REFERENCES `roles`(`employeeid`) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (`overtime_approved_by`) REFERENCES `roles`(`employeeid`) ON DELETE SET NULL ON UPDATE CASCADE,
    
    UNIQUE KEY `unique_employee_date` (`employeeid`, `attendance_date`),
    INDEX `idx_attendance_date` (`attendance_date`),
    INDEX `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- LEAVE MANAGEMENT
-- =====================================================

-- Employee Leave Applications
CREATE TABLE IF NOT EXISTS `payroll_employee_leave` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `employeeid` INT UNSIGNED NOT NULL,
    `leave_type` ENUM('annual', 'sick', 'maternity', 'paternity', 'unpaid', 'study', 'compassionate') NOT NULL,
    `start_date` DATE NOT NULL,
    `end_date` DATE NOT NULL,
    `total_days` INT NOT NULL,
    
    -- Status workflow
    `status` ENUM('pending', 'approved', 'rejected', 'cancelled') DEFAULT 'pending',
    `applied_date` DATE NOT NULL,
    `approved_by` INT UNSIGNED NULL,
    `approved_date` DATE NULL,
    
    `affects_salary` BOOLEAN DEFAULT FALSE,
    
    `reason` TEXT NULL,
    `attachments` TEXT NULL, -- JSON array of file paths
    
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (`employeeid`) REFERENCES `roles`(`employeeid`) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (`approved_by`) REFERENCES `roles`(`employeeid`) ON DELETE SET NULL ON UPDATE CASCADE,
    
    INDEX `idx_employeeid` (`employeeid`),
    INDEX `idx_status` (`status`),
    INDEX `idx_date_range` (`start_date`, `end_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Employee Leave Balance
CREATE TABLE IF NOT EXISTS `payroll_employee_leave_balance` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `employeeid` INT UNSIGNED NOT NULL,
    `leave_year` INT NOT NULL,
    
    -- Entitlements
    `annual_leave_entitlement` INT DEFAULT 21,
    `sick_leave_entitlement` INT DEFAULT 14,
    
    -- Balances
    `annual_leave_taken` INT DEFAULT 0,
    `annual_leave_balance` INT DEFAULT 21,
    `sick_leave_taken` INT DEFAULT 0,
    `sick_leave_balance` INT DEFAULT 14,
    
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (`employeeid`) REFERENCES `roles`(`employeeid`) ON DELETE CASCADE ON UPDATE CASCADE,
    
    UNIQUE KEY `unique_employee_year` (`employeeid`, `leave_year`),
    INDEX `idx_leave_year` (`leave_year`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- ALLOWANCES AND BONUSES
-- =====================================================

-- Employee Allowances
CREATE TABLE IF NOT EXISTS `payroll_employee_allowances` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `employeeid` INT UNSIGNED NOT NULL,
    `allowance_type` ENUM('housing', 'transport', 'meal', 'medical', 'education', 
                          'uniform', 'mobile', 'hazard', 'shift_allowance', 'professional_development') NOT NULL,
    
    `amount` DECIMAL(10, 2) NOT NULL,
    `calculation_method` ENUM('fixed', 'percentage_of_basic', 'variable') DEFAULT 'fixed',
    `percentage` DECIMAL(5, 2) NULL,
    
    -- Frequency
    `is_recurring` BOOLEAN DEFAULT TRUE,
    `frequency` ENUM('monthly', 'quarterly', 'annually', 'one-time') DEFAULT 'monthly',
    
    `is_taxable` BOOLEAN DEFAULT TRUE,
    
    -- Effective dates
    `effective_from` DATE NOT NULL,
    `effective_to` DATE NULL,
    `is_active` BOOLEAN DEFAULT TRUE,
    
    `approved_by` INT UNSIGNED NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (`employeeid`) REFERENCES `roles`(`employeeid`) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (`approved_by`) REFERENCES `roles`(`employeeid`) ON DELETE SET NULL ON UPDATE CASCADE,
    
    INDEX `idx_employeeid` (`employeeid`),
    INDEX `idx_is_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Employee Bonuses
CREATE TABLE IF NOT EXISTS `payroll_employee_bonuses` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `employeeid` INT UNSIGNED NOT NULL,
    `bonus_type` ENUM('performance', 'annual', 'project', 'retention', 'holiday', 'spot') NOT NULL,
    
    `amount` DECIMAL(10, 2) NOT NULL,
    `bonus_period` VARCHAR(50) NULL,
    
    `is_taxable` BOOLEAN DEFAULT TRUE,
    `tax_method` ENUM('aggregate', 'separate', 'bonus_rate') DEFAULT 'aggregate',
    
    -- Approval workflow
    `status` ENUM('pending', 'approved', 'rejected', 'paid') DEFAULT 'pending',
    `approved_by` INT UNSIGNED NULL,
    `approved_date` DATE NULL,
    
    `reason` TEXT NULL,
    `performance_rating` DECIMAL(3, 2) NULL,
    
    `payment_date` DATE NULL,
    `payroll_period_id` INT UNSIGNED NULL,
    
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (`employeeid`) REFERENCES `roles`(`employeeid`) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (`approved_by`) REFERENCES `roles`(`employeeid`) ON DELETE SET NULL ON UPDATE CASCADE,
    
    INDEX `idx_employeeid` (`employeeid`),
    INDEX `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- TAX AND STATUTORY DEDUCTIONS
-- =====================================================

-- Tax Configuration (Ghana Tax System)
CREATE TABLE IF NOT EXISTS `payroll_tax_configuration` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `tax_year` VARCHAR(4) NOT NULL,
    `country` VARCHAR(50) DEFAULT 'Ghana',
    
    -- Tax bands (JSON structure: [{"min": 0, "max": 4380, "rate": 0}, {"min": 4381, "max": 6000, "rate": 5}])
    `tax_bands` JSON NOT NULL,
    
    -- Exemptions and reliefs
    `standard_exemption` DECIMAL(10, 2) DEFAULT 0,
    `dependent_relief` DECIMAL(10, 2) DEFAULT 0,
    `disability_exemption` DECIMAL(10, 2) DEFAULT 0,
    
    -- Social security rates (SSNIT)
    `employee_ssnit_rate` DECIMAL(5, 2) DEFAULT 5.5,
    `employer_ssnit_rate` DECIMAL(5, 2) DEFAULT 13,
    `tier3_employee_rate` DECIMAL(5, 2) DEFAULT 5,
    `tier3_employer_rate` DECIMAL(5, 2) DEFAULT 5,
    
    -- Ceilings
    `ssnit_ceiling` DECIMAL(10, 2) NULL,
    `pension_ceiling` DECIMAL(10, 2) NULL,
    
    `is_active` BOOLEAN DEFAULT TRUE,
    
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    `created_by` INT UNSIGNED NULL,
    
    FOREIGN KEY (`created_by`) REFERENCES `roles`(`employeeid`) ON DELETE SET NULL ON UPDATE CASCADE,
    
    UNIQUE KEY `unique_tax_year` (`tax_year`),
    INDEX `idx_is_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Employee Statutory Deductions (SSNIT, Tax, NHIS, Tier 3)
CREATE TABLE IF NOT EXISTS `payroll_employee_statutory_deductions` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `employeeid` INT UNSIGNED NOT NULL,
    
    -- SSNIT (Social Security)
    `ssnit_number` VARCHAR(50) NULL UNIQUE,
    `ssnit_active` BOOLEAN DEFAULT TRUE,
    `ssnit_employee_rate` DECIMAL(5, 2) DEFAULT 5.5,
    
    -- Tier 3 Pension (Voluntary)
    `tier3_enrolled` BOOLEAN DEFAULT FALSE,
    `tier3_scheme_name` VARCHAR(100) NULL,
    `tier3_scheme_number` VARCHAR(50) NULL,
    `tier3_employee_rate` DECIMAL(5, 2) DEFAULT 5,
    `tier3_employer_rate` DECIMAL(5, 2) DEFAULT 5,
    
    -- Tax (PAYE)
    `tin_number` VARCHAR(50) NULL UNIQUE,
    `tax_exempt` BOOLEAN DEFAULT FALSE,
    `tax_exempt_reason` TEXT NULL,
    `dependents_count` INT DEFAULT 0,
    
    -- NHIS (National Health Insurance Scheme)
    `nhis_number` VARCHAR(50) NULL,
    `nhis_active` BOOLEAN DEFAULT FALSE,
    `nhis_rate` DECIMAL(5, 2) DEFAULT 2.5,
    
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (`employeeid`) REFERENCES `roles`(`employeeid`) ON DELETE CASCADE ON UPDATE CASCADE,
    
    INDEX `idx_employeeid` (`employeeid`),
    INDEX `idx_ssnit_number` (`ssnit_number`),
    INDEX `idx_tin_number` (`tin_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Employee Other Deductions (Loans, Advances, etc.)
CREATE TABLE IF NOT EXISTS `payroll_employee_other_deductions` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `employeeid` INT UNSIGNED NOT NULL,
    `deduction_type` ENUM('loan', 'advance', 'garnishment', 'union_dues', 'insurance',
                          'cooperative', 'welfare', 'savings', 'disciplinary', 'other') NOT NULL,
    
    `deduction_name` VARCHAR(100) NOT NULL,
    `amount` DECIMAL(10, 2) NOT NULL,
    
    -- Frequency and limits
    `is_recurring` BOOLEAN DEFAULT TRUE,
    `frequency` ENUM('monthly', 'bi-weekly', 'weekly', 'one-time') DEFAULT 'monthly',
    `total_amount` DECIMAL(10, 2) NULL, -- For loans/advances
    `remaining_balance` DECIMAL(10, 2) NULL,
    
    -- Priority (lower number = higher priority)
    `deduction_priority` INT DEFAULT 10,
    
    -- Dates
    `start_date` DATE NOT NULL,
    `end_date` DATE NULL,
    `is_active` BOOLEAN DEFAULT TRUE,
    
    -- Approval
    `approved_by` INT UNSIGNED NULL,
    `approved_date` DATE NULL,
    
    `remarks` TEXT NULL,
    `attachments` TEXT NULL, -- JSON array of file paths
    
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (`employeeid`) REFERENCES `roles`(`employeeid`) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (`approved_by`) REFERENCES `roles`(`employeeid`) ON DELETE SET NULL ON UPDATE CASCADE,
    
    INDEX `idx_employeeid` (`employeeid`),
    INDEX `idx_is_active` (`is_active`),
    INDEX `idx_deduction_type` (`deduction_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- PAYROLL PROCESSING
-- =====================================================

-- Payroll Periods (Monthly Payroll Cycles)
CREATE TABLE IF NOT EXISTS `payroll_periods` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `period_name` VARCHAR(50) NOT NULL, -- e.g., "January 2024"
    `period_year` INT NOT NULL,
    `period_month` INT NOT NULL,
    
    `period_start_date` DATE NOT NULL,
    `period_end_date` DATE NOT NULL,
    `payment_date` DATE NOT NULL,
    
    -- Attendance tracking period (may differ from payment period)
    `attendance_start_date` DATE NOT NULL,
    `attendance_end_date` DATE NOT NULL,
    
    `status` ENUM('draft', 'calculated', 'approved', 'locked', 'paid') DEFAULT 'draft',
    
    -- Totals
    `total_gross_salary` DECIMAL(12, 2) DEFAULT 0,
    `total_deductions` DECIMAL(12, 2) DEFAULT 0,
    `total_net_salary` DECIMAL(12, 2) DEFAULT 0,
    `employee_count` INT DEFAULT 0,
    
    -- Approval workflow
    `calculated_by` INT UNSIGNED NULL,
    `calculated_at` DATETIME NULL,
    `approved_by` INT UNSIGNED NULL,
    `approved_at` DATETIME NULL,
    `locked_by` INT UNSIGNED NULL,
    `locked_at` DATETIME NULL,
    
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (`calculated_by`) REFERENCES `roles`(`employeeid`) ON DELETE SET NULL ON UPDATE CASCADE,
    FOREIGN KEY (`approved_by`) REFERENCES `roles`(`employeeid`) ON DELETE SET NULL ON UPDATE CASCADE,
    FOREIGN KEY (`locked_by`) REFERENCES `roles`(`employeeid`) ON DELETE SET NULL ON UPDATE CASCADE,
    
    UNIQUE KEY `unique_period` (`period_year`, `period_month`),
    INDEX `idx_status` (`status`),
    INDEX `idx_date_range` (`period_start_date`, `period_end_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Payroll Transactions (Individual Employee Payroll Records)
CREATE TABLE IF NOT EXISTS `payroll_transactions` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `payroll_period_id` INT UNSIGNED NOT NULL,
    `employeeid` INT UNSIGNED NOT NULL,
    
    -- Earnings breakdown
    `basic_salary` DECIMAL(10, 2) DEFAULT 0,
    `hourly_earnings` DECIMAL(10, 2) DEFAULT 0,
    `overtime_earnings` DECIMAL(10, 2) DEFAULT 0,
    `commission_earnings` DECIMAL(10, 2) DEFAULT 0,
    `total_allowances` DECIMAL(10, 2) DEFAULT 0,
    `total_bonuses` DECIMAL(10, 2) DEFAULT 0,
    `gross_salary` DECIMAL(10, 2) NOT NULL,
    
    -- Deductions breakdown
    `income_tax` DECIMAL(10, 2) DEFAULT 0,
    `employee_ssnit` DECIMAL(10, 2) DEFAULT 0,
    `employer_ssnit` DECIMAL(10, 2) DEFAULT 0,
    `employee_tier3` DECIMAL(10, 2) DEFAULT 0,
    `employer_tier3` DECIMAL(10, 2) DEFAULT 0,
    `nhis` DECIMAL(10, 2) DEFAULT 0,
    `total_other_deductions` DECIMAL(10, 2) DEFAULT 0,
    `total_deductions` DECIMAL(10, 2) NOT NULL,
    
    -- Final amounts
    `net_salary` DECIMAL(10, 2) NOT NULL,
    `employer_cost` DECIMAL(10, 2) NOT NULL, -- Total cost to employer
    
    -- Attendance summary
    `days_worked` INT DEFAULT 0,
    `hours_worked` DECIMAL(5, 2) DEFAULT 0,
    `overtime_hours` DECIMAL(5, 2) DEFAULT 0,
    `days_absent` INT DEFAULT 0,
    `days_leave` INT DEFAULT 0,
    
    -- Status
    `status` ENUM('pending', 'approved', 'paid', 'cancelled') DEFAULT 'pending',
    `payment_date` DATE NULL,
    
    -- Payment details
    `payment_method` ENUM('bank_transfer', 'cash', 'cheque', 'mobile_money') NULL,
    `payment_reference` VARCHAR(100) NULL,
    
    -- Detailed breakdown (JSON)
    `allowances_detail` JSON NULL, -- [{"type": "housing", "amount": 500}]
    `bonuses_detail` JSON NULL, -- [{"type": "performance", "amount": 1000}]
    `other_deductions_detail` JSON NULL, -- [{"type": "loan", "amount": 200}]
    
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (`payroll_period_id`) REFERENCES `payroll_periods`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (`employeeid`) REFERENCES `roles`(`employeeid`) ON DELETE CASCADE ON UPDATE CASCADE,
    
    UNIQUE KEY `unique_period_employee` (`payroll_period_id`, `employeeid`),
    INDEX `idx_status` (`status`),
    INDEX `idx_payment_date` (`payment_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- ADJUSTMENTS AND CORRECTIONS
-- =====================================================

-- Payroll Adjustments (Arrears, Corrections, etc.)
CREATE TABLE IF NOT EXISTS `payroll_adjustments` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `payroll_transaction_id` INT UNSIGNED NOT NULL,
    `employeeid` INT UNSIGNED NOT NULL,
    
    `adjustment_type` ENUM('earning', 'deduction') NOT NULL,
    `adjustment_category` ENUM('arrears', 'correction', 'refund', 'advance_recovery',
                               'retroactive_payment', 'overpayment_recovery', 'manual_adjustment') NOT NULL,
    
    `description` VARCHAR(255) NOT NULL,
    `amount` DECIMAL(10, 2) NOT NULL,
    
    `is_taxable` BOOLEAN DEFAULT TRUE,
    `affects_ssnit` BOOLEAN DEFAULT TRUE,
    
    -- Approval workflow
    `status` ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
    `requested_by` INT UNSIGNED NOT NULL,
    `approved_by` INT UNSIGNED NULL,
    `approved_date` DATE NULL,
    
    `justification` TEXT NULL,
    `attachments` TEXT NULL, -- JSON array
    
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (`payroll_transaction_id`) REFERENCES `payroll_transactions`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (`employeeid`) REFERENCES `roles`(`employeeid`) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (`requested_by`) REFERENCES `roles`(`employeeid`) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (`approved_by`) REFERENCES `roles`(`employeeid`) ON DELETE SET NULL ON UPDATE CASCADE,
    
    INDEX `idx_payroll_transaction_id` (`payroll_transaction_id`),
    INDEX `idx_employeeid` (`employeeid`),
    INDEX `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- AUDIT AND COMPLIANCE
-- =====================================================

-- Payroll Audit Log (Complete Audit Trail)
CREATE TABLE IF NOT EXISTS `payroll_audit_log` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `employeeid` INT UNSIGNED NULL,
    `payroll_period_id` INT UNSIGNED NULL,
    `payroll_transaction_id` INT UNSIGNED NULL,
    
    `action_type` ENUM('period_created', 'period_calculated', 'period_approved', 'period_locked', 'period_paid',
                       'transaction_created', 'transaction_updated', 'transaction_approved', 'transaction_paid',
                       'adjustment_added', 'adjustment_approved', 'allowance_added', 'deduction_added',
                       'compensation_updated', 'statutory_updated', 'tax_config_updated') NOT NULL,
    
    `entity_type` VARCHAR(50) NOT NULL, -- e.g., 'payroll_period', 'payroll_transaction'
    `entity_id` INT UNSIGNED NOT NULL,
    
    `old_values` JSON NULL,
    `new_values` JSON NULL,
    
    `description` TEXT NULL,
    `ip_address` VARCHAR(45) NULL,
    `user_agent` VARCHAR(255) NULL,
    
    `performed_by` INT UNSIGNED NOT NULL,
    `performed_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (`employeeid`) REFERENCES `roles`(`employeeid`) ON DELETE SET NULL ON UPDATE CASCADE,
    FOREIGN KEY (`payroll_period_id`) REFERENCES `payroll_periods`(`id`) ON DELETE SET NULL ON UPDATE CASCADE,
    FOREIGN KEY (`payroll_transaction_id`) REFERENCES `payroll_transactions`(`id`) ON DELETE SET NULL ON UPDATE CASCADE,
    FOREIGN KEY (`performed_by`) REFERENCES `roles`(`employeeid`) ON DELETE CASCADE ON UPDATE CASCADE,
    
    INDEX `idx_action_type` (`action_type`),
    INDEX `idx_performed_at` (`performed_at`),
    INDEX `idx_entity_type` (`entity_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- COST ALLOCATION
-- =====================================================

-- Payroll Cost Centers (Department/Branch Allocation)
CREATE TABLE IF NOT EXISTS `payroll_cost_centers` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `cost_center_code` VARCHAR(50) NOT NULL UNIQUE,
    `cost_center_name` VARCHAR(100) NOT NULL,
    `department` ENUM('laboratory', 'radiology', 'front_desk', 'administration',
                     'finance', 'it', 'maintenance', 'security', 'management') NOT NULL,
    
    `branch_id` INT UNSIGNED NULL,
    
    `is_active` BOOLEAN DEFAULT TRUE,
    
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (`branch_id`) REFERENCES `branch`(`branchid`) ON DELETE SET NULL ON UPDATE CASCADE,
    
    INDEX `idx_department` (`department`),
    INDEX `idx_is_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Employee Cost Center Allocation
CREATE TABLE IF NOT EXISTS `payroll_employee_cost_center_allocation` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `employeeid` INT UNSIGNED NOT NULL,
    `cost_center_id` INT UNSIGNED NOT NULL,
    `allocation_percentage` DECIMAL(5, 2) NOT NULL DEFAULT 100,
    
    `effective_from` DATE NOT NULL,
    `effective_to` DATE NULL,
    `is_active` BOOLEAN DEFAULT TRUE,
    
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (`employeeid`) REFERENCES `roles`(`employeeid`) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (`cost_center_id`) REFERENCES `payroll_cost_centers`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
    
    INDEX `idx_employeeid` (`employeeid`),
    INDEX `idx_is_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- PAYSLIP MANAGEMENT
-- =====================================================

-- Payslip Templates (Customizable Payslip Layouts)
CREATE TABLE IF NOT EXISTS `payroll_payslip_templates` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `template_name` VARCHAR(100) NOT NULL,
    `template_html` TEXT NOT NULL,
    
    `show_employer_contributions` BOOLEAN DEFAULT TRUE,
    `show_cost_center` BOOLEAN DEFAULT FALSE,
    `show_attendance_summary` BOOLEAN DEFAULT TRUE,
    `show_ytd_totals` BOOLEAN DEFAULT TRUE,
    
    `custom_fields` JSON NULL, -- Additional fields to display
    
    `is_default` BOOLEAN DEFAULT FALSE,
    `is_active` BOOLEAN DEFAULT TRUE,
    
    `created_by` INT UNSIGNED NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (`created_by`) REFERENCES `roles`(`employeeid`) ON DELETE SET NULL ON UPDATE CASCADE,
    
    INDEX `idx_is_default` (`is_default`),
    INDEX `idx_is_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Employee Payslip Access (Track Payslip Views/Downloads)
CREATE TABLE IF NOT EXISTS `payroll_employee_payslip_access` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `employeeid` INT UNSIGNED NOT NULL,
    `payroll_transaction_id` INT UNSIGNED NOT NULL,
    
    `accessed_at` DATETIME NOT NULL,
    `ip_address` VARCHAR(45) NULL,
    `user_agent` VARCHAR(255) NULL,
    `access_type` ENUM('view', 'download', 'email') NOT NULL,
    
    FOREIGN KEY (`employeeid`) REFERENCES `roles`(`employeeid`) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (`payroll_transaction_id`) REFERENCES `payroll_transactions`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
    
    INDEX `idx_employeeid` (`employeeid`),
    INDEX `idx_accessed_at` (`accessed_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

