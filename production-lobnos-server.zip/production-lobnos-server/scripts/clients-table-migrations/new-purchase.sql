-- Purchase Order System Database Schema
-- Generated from Knex migrations for the new purchase order functionality
-- Date: November 10, 2025

-- =====================================================
-- INVENTORY MANAGEMENT SYSTEM TABLES
-- =====================================================

-- Suppliers table (if not exists)
CREATE TABLE IF NOT EXISTS `inv_suppliers` (
  `id` varchar(50) NOT NULL,
  `name` varchar(255) NOT NULL COMMENT 'Company name',
  `contact` varchar(255) DEFAULT NULL COMMENT 'Primary contact person name',
  `email` varchar(255) DEFAULT NULL COMMENT 'Primary contact email',
  `phone` varchar(50) DEFAULT NULL COMMENT 'Primary contact phone',
  `address` text COMMENT 'Supplier address',
  `is_active` tinyint(1) DEFAULT 1 COMMENT 'Whether supplier is active',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_supplier_contact` (`contact`),
  UNIQUE KEY `unique_supplier_email` (`email`),
  KEY `idx_inv_supplier_name` (`name`),
  KEY `idx_inv_supplier_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Categories table (if not exists)
CREATE TABLE IF NOT EXISTS `inv_categories` (
  `id` varchar(50) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text,
  `item_count` int(11) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `inv_categories_name_unique` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Storage locations table (if not exists)
CREATE TABLE IF NOT EXISTS `inv_storage_locations` (
  `id` varchar(50) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text,
  `capacity` int(11) DEFAULT NULL,
  `temperature_controlled` tinyint(1) DEFAULT 0,
  `temperature_range` varchar(100) DEFAULT NULL,
  `hazardous_materials` tinyint(1) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `inv_storage_locations_name_unique` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `inv_brands` (
 `id` varchar(50) NOT NULL COMMENT 'UUID or auto-generated unique identifier',
 `name` varchar(255) NOT NULL COMMENT 'Brand name - must be unique across system',
 `created_date` timestamp NULL DEFAULT current_timestamp() COMMENT 'Date brand was first added to system',
 `item_count` int(10) UNSIGNED DEFAULT 0 COMMENT 'Computed: number of active inventory items using this brand',
 `created_at` timestamp NULL DEFAULT current_timestamp() COMMENT 'Record creation timestamp',
 `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp() COMMENT 'Last modification timestamp',
 `inventory_item_id` varchar(50) DEFAULT NULL COMMENT 'Reference to inventory item',
 PRIMARY KEY (`id`),
 UNIQUE KEY `inv_brands_name_unique` (`name`),
 KEY `idx_inv_brand_name` (`name`),
 KEY `idx_inv_brand_created_date` (`created_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Inventory Templates table
CREATE TABLE IF NOT EXISTS `inv_inventory_templates` (
 `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
 `name` varchar(255) NOT NULL,
 `createby` int(10) unsigned NOT NULL,
 `description` text DEFAULT NULL,
 `testId` varchar(255) NOT NULL,
 `created_at` timestamp NULL DEFAULT current_timestamp(),
 `updated_at` timestamp NULL DEFAULT current_timestamp(),
 PRIMARY KEY (`id`),
 UNIQUE KEY `inv_inventory_templates_name_unique` (`name`),
 KEY `inv_inventory_templates_createby_foreign` (`createby`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Inventory Template Items table
CREATE TABLE IF NOT EXISTS `inv_inventory_template_items` (
 `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
 `template_id` int(10) unsigned NOT NULL,
 `itemId` varchar(255) NOT NULL,
 `quantity` decimal(10,2) NOT NULL,
 `created_at` timestamp NULL DEFAULT current_timestamp(),
 PRIMARY KEY (`id`),
 KEY `inv_inventory_template_items_itemid_foreign` (`itemId`),
 KEY `inv_inventory_template_items_template_id_foreign` (`template_id`),
 CONSTRAINT `inv_inventory_template_items_itemid_foreign` FOREIGN KEY (`itemId`) REFERENCES `inv_inventory_items` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
 CONSTRAINT `inv_inventory_template_items_template_id_foreign` FOREIGN KEY (`template_id`) REFERENCES `inv_inventory_templates` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Inventory items table (if not exists)
CREATE TABLE IF NOT EXISTS `inv_inventory_items` (
  `id` varchar(50) NOT NULL,
  `name` varchar(255) NOT NULL COMMENT 'Item name',
  `sku` varchar(100) NOT NULL COMMENT 'Stock Keeping Unit - unique identifier',
  `description` text COMMENT 'Detailed item description',
  `category_id` varchar(50) DEFAULT NULL,
  `unit` varchar(50) DEFAULT 'pieces' COMMENT 'Unit of measurement',
  `current_stock` int(11) DEFAULT 0 COMMENT 'Current quantity in stock',
  `min_stock` int(11) DEFAULT 0 COMMENT 'Minimum stock level threshold',
  `max_stock` int(11) DEFAULT 0 COMMENT 'Maximum stock level (optional)',
  `location_id` varchar(50) DEFAULT NULL,
  `status` enum('in_stock','low_stock','out_of_stock','expired') DEFAULT 'out_of_stock' COMMENT 'Computed stock status',
  `is_active` tinyint(1) DEFAULT 1 COMMENT 'Item is active in system',
  `last_updated` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Last stock change',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `inv_inventory_items_sku_unique` (`sku`),
  KEY `idx_inv_item_sku` (`sku`),
  KEY `idx_inv_item_name` (`name`),
  KEY `idx_inv_item_category` (`category_id`),
  KEY `idx_inv_item_location` (`location_id`),
  KEY `idx_inv_item_status` (`status`),
  KEY `idx_inv_item_active` (`is_active`),
  KEY `idx_inv_item_stock_levels` (`current_stock`,`min_stock`,`max_stock`),
  KEY `inv_inventory_items_category_id_foreign` (`category_id`),
  KEY `inv_inventory_items_location_id_foreign` (`location_id`),
  CONSTRAINT `inv_inventory_items_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `inv_categories` (`id`) ON DELETE SET NULL,
  CONSTRAINT `inv_inventory_items_location_id_foreign` FOREIGN KEY (`location_id`) REFERENCES `inv_storage_locations` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- PURCHASE ORDER SYSTEM TABLES
-- =====================================================

-- Purchase Orders table
CREATE TABLE IF NOT EXISTS `inv_purchase_orders` (
  `id` varchar(50) NOT NULL,
  `order_number` varchar(100) NOT NULL COMMENT 'Auto-generated order number (ORD-YYYY-MM-DD-NNNN)',
  `supplier_id` varchar(50) NOT NULL,
  `order_date` date NOT NULL,
  `expected_delivery_date` date DEFAULT NULL,
  `status` enum('ordered','partially_received','received','cancelled') DEFAULT 'ordered',
  `total_amount` decimal(12,2) DEFAULT 0.00,
  `communication_method` varchar(50) DEFAULT NULL COMMENT 'Method used to communicate with supplier (email, phone, fax, etc.)',
  `communication_notes` text COMMENT 'Notes about communication with supplier',
  `notes` text,
  `created_by` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `inv_purchase_orders_order_number_unique` (`order_number`),
  KEY `inv_purchase_orders_supplier_id_foreign` (`supplier_id`),
  KEY `idx_po_order_supplier_status_date` (`order_number`,`supplier_id`,`status`,`order_date`),
  CONSTRAINT `inv_purchase_orders_supplier_id_foreign` FOREIGN KEY (`supplier_id`) REFERENCES `inv_suppliers` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Purchase Order Items table
CREATE TABLE IF NOT EXISTS `inv_purchase_order_items` (
  `id` varchar(50) NOT NULL,
  `order_id` varchar(50) NOT NULL,
  `inventory_item_id` varchar(50) DEFAULT NULL,
  `quantity_ordered` int(11) NOT NULL,
  `quantity_received` int(11) DEFAULT 0,
  `unit_price` decimal(10,2) NOT NULL,
  `tax_rate` decimal(5,2) DEFAULT 0.00,
  `discount_rate` decimal(5,2) DEFAULT 0.00,
  `line_total` decimal(12,2) NOT NULL,
  `status` enum('pending','partially_received','received','cancelled') DEFAULT 'pending',
  `notes` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `inv_purchase_order_items_order_id_foreign` (`order_id`),
  KEY `inv_purchase_order_items_inventory_item_id_foreign` (`inventory_item_id`),
  KEY `idx_poi_order_item_status` (`order_id`,`inventory_item_id`,`status`),
  CONSTRAINT `inv_purchase_order_items_inventory_item_id_foreign` FOREIGN KEY (`inventory_item_id`) REFERENCES `inv_inventory_items` (`id`),
  CONSTRAINT `inv_purchase_order_items_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `inv_purchase_orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Purchase Order Receipts table
CREATE TABLE IF NOT EXISTS `inv_purchase_order_receipts` (
  `id` varchar(50) NOT NULL,
  `order_id` varchar(50) NOT NULL,
  `order_item_id` varchar(50) NOT NULL,
  `receipt_number` varchar(100) NOT NULL,
  `received_date` date NOT NULL,
  `received_by` varchar(100) DEFAULT NULL,
  `quantity_received` int(11) NOT NULL,
  `batch_number` varchar(100) DEFAULT NULL,
  `expiry_date` date DEFAULT NULL,
  `unit_price` decimal(10,2) DEFAULT NULL,
  `tax_rate` decimal(5,2) DEFAULT NULL,
  `discount_rate` decimal(5,2) DEFAULT NULL,
  `condition_status` enum('good','acceptable','damaged','expired') DEFAULT 'good',
  `quality_check_passed` tinyint(1) DEFAULT 1,
  `notes` text,
  `image_url` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `inv_purchase_order_receipts_receipt_number_unique` (`receipt_number`),
  KEY `inv_purchase_order_receipts_order_id_foreign` (`order_id`),
  KEY `inv_purchase_order_receipts_order_item_id_foreign` (`order_item_id`),
  KEY `idx_receipt_order_item_date_batch` (`order_id`,`order_item_id`,`received_date`,`batch_number`),
  CONSTRAINT `inv_purchase_order_receipts_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `inv_purchase_orders` (`id`),
  CONSTRAINT `inv_purchase_order_receipts_order_item_id_foreign` FOREIGN KEY (`order_item_id`) REFERENCES `inv_purchase_order_items` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Inventory Transactions table
CREATE TABLE IF NOT EXISTS `inv_inventory_transactions` (
  `id` varchar(50) NOT NULL,
  `item_id` varchar(50) NOT NULL,
  `transaction_type` enum('addition','consumption','adjustment','transfer') NOT NULL,
  `quantity` int(11) NOT NULL,
  `previous_stock` int(11) NOT NULL,
  `new_stock` int(11) NOT NULL,
  `batch_number` varchar(100) DEFAULT NULL,
  `expiry_date` date DEFAULT NULL,
  `unit_cost` decimal(10,2) DEFAULT NULL,
  `total_cost` decimal(12,2) DEFAULT NULL,
  `brand_name` varchar(255) DEFAULT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `reference_id` varchar(50) DEFAULT NULL,
  `performed_by` varchar(100) DEFAULT NULL,
  `transaction_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `notes` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `inv_inventory_transactions_item_id_foreign` (`item_id`),
  KEY `idx_txn_item_type_date_batch_ref` (`item_id`,`transaction_type`,`transaction_date`,`batch_number`,`reference_id`),
  CONSTRAINT `inv_inventory_transactions_item_id_foreign` FOREIGN KEY (`item_id`) REFERENCES `inv_inventory_items` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Consumption History table
CREATE TABLE IF NOT EXISTS `inv_consumption_history` (
  `id` varchar(50) NOT NULL,
  `item_id` varchar(50) NOT NULL,
  `quantity_consumed` int(11) NOT NULL,
  `consumed_by` varchar(100) DEFAULT NULL COMMENT 'User who consumed the item',
  `consumption_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `batch_number` varchar(100) DEFAULT NULL,
  `unit_cost` decimal(10,2) DEFAULT NULL COMMENT 'Cost per unit at time of consumption',
  `total_cost` decimal(12,2) DEFAULT NULL COMMENT 'Total cost of consumption',
  `consumption_reason` varchar(255) DEFAULT NULL COMMENT 'Reason for consumption (patient use, testing, etc.)',
  `department` varchar(100) DEFAULT NULL COMMENT 'Department where consumption occurred',
  `patientid` int(10) unsigned DEFAULT NULL COMMENT 'Patient ID if consumption was for patient use',
  `prescription_id` varchar(50) DEFAULT NULL COMMENT 'Prescription ID if applicable',
  `brand_name` varchar(255) DEFAULT NULL COMMENT 'Brand name of the item consumed',
  `notes` text,
  `approved_by` varchar(100) DEFAULT NULL COMMENT 'User who approved the consumption',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `inv_consumption_history_item_id_foreign` (`item_id`),
  KEY `idx_consumption_date_item` (`consumption_date`, `item_id`),
  KEY `idx_consumption_user_date` (`consumed_by`, `consumption_date`),
  KEY `idx_consumption_batch` (`batch_number`),
  KEY `idx_consumption_reason` (`consumption_reason`),
  KEY `idx_consumption_department` (`department`),
  KEY `idx_consumption_patient` (`patientid`),
  CONSTRAINT `inv_consumption_history_item_id_foreign` FOREIGN KEY (`item_id`) REFERENCES `inv_inventory_items` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- USEFUL INDEXES FOR PERFORMANCE
-- =====================================================

-- Additional indexes for common queries
CREATE INDEX IF NOT EXISTS  idx_purchase_orders_status_date ON inv_purchase_orders(status, order_date);
CREATE INDEX IF NOT EXISTS  idx_purchase_orders_supplier_date ON inv_purchase_orders(supplier_id, order_date);
CREATE INDEX IF NOT EXISTS  idx_order_items_status ON inv_purchase_order_items(status);
CREATE INDEX IF NOT EXISTS  idx_receipts_batch_expiry ON inv_purchase_order_receipts(batch_number, expiry_date);
CREATE INDEX IF NOT EXISTS  idx_transactions_date_type ON inv_inventory_transactions(transaction_date, transaction_type);
CREATE INDEX IF NOT EXISTS  idx_transactions_reference ON inv_inventory_transactions(reference_id, transaction_type);
CREATE INDEX IF NOT EXISTS  idx_consumption_history_date_type ON inv_consumption_history(consumption_date, item_id);

-- Migration to add wastage_type column to inv_inventory_transactions table
-- This migration adds support for categorizing wastage transactions

ALTER TABLE `inv_inventory_transactions`
ADD COLUMN IF NOT EXISTS `wastage_type` enum('expired','damaged','broken','contamination','other') DEFAULT NULL COMMENT 'Type of wastage for wastage transactions' AFTER `notes`;

-- Update the transaction_type enum to include 'wastage'
ALTER TABLE `inv_inventory_transactions`
MODIFY COLUMN `transaction_type` enum('addition','consumption','adjustment','transfer','wastage') NOT NULL COMMENT 'Type of transaction';



CREATE TABLE IF NOT EXISTS `inv_supplier_payments` (
 `id` varchar(50) NOT NULL,
 `payment_id` varchar(50) NOT NULL COMMENT 'Human-readable payment reference ID',
 `supplier_id` varchar(50) NOT NULL COMMENT 'Supplier being paid',
 `purchase_order_id` varchar(50) NOT NULL COMMENT 'Purchase order this payment is for',
 `payment_amount` decimal(12,2) NOT NULL COMMENT 'Total payment amount',
 `total_allocated` decimal(12,2) DEFAULT 0.00 COMMENT 'Total of all allocations for this payment',
 `payment_date` date NOT NULL COMMENT 'Date payment was made',
 `payment_method` enum('cash','check','bank_transfer','credit_card','wire_transfer','other') DEFAULT 'bank_transfer' COMMENT 'Method of payment',
 `payment_status` enum('pending','completed','failed','cancelled','refunded','reject') DEFAULT 'pending' COMMENT 'Current status of payment',
 `reference_number` varchar(100) DEFAULT NULL COMMENT 'Check number, transaction ID, or other reference',
 `payment_notes` text DEFAULT NULL COMMENT 'Additional notes about the payment',
 `created_by` varchar(100) DEFAULT NULL COMMENT 'User who created the payment record',
 `approved_by` varchar(100) DEFAULT NULL COMMENT 'User who approved the payment',
 `approved_at` timestamp NULL DEFAULT NULL COMMENT 'When payment was approved',
 `processed_at` timestamp NULL DEFAULT NULL COMMENT 'When payment was actually processed',
 `created_at` timestamp NULL DEFAULT current_timestamp(),
 `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
 PRIMARY KEY (`id`),
 UNIQUE KEY `inv_supplier_payments_payment_id_unique` (`payment_id`),
 KEY `inv_supplier_payments_supplier_id_foreign` (`supplier_id`),
 KEY `inv_supplier_payments_purchase_order_id_foreign` (`purchase_order_id`),
 KEY `idx_supplier_payment_status_date` (`supplier_id`,`payment_status`,`payment_date`),
 KEY `idx_payment_po_status` (`purchase_order_id`,`payment_status`),
 KEY `idx_payment_date_status` (`payment_date`,`payment_status`),
 KEY `idx_payment_method` (`payment_method`),
 KEY `idx_payment_reference` (`reference_number`),
 KEY `idx_supplier_payments_created_date` (`created_at`),
 KEY `idx_supplier_payments_updated_date` (`updated_at`),
 KEY `idx_supplier_payments_payment_id` (`payment_id`),
 CONSTRAINT `inv_supplier_payments_purchase_order_id_foreign` FOREIGN KEY (`purchase_order_id`) REFERENCES `inv_purchase_orders` (`id`),
 CONSTRAINT `inv_supplier_payments_supplier_id_foreign` FOREIGN KEY (`supplier_id`) REFERENCES `inv_suppliers` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Tracks payments made to suppliers for purchase orders';

-- Supplier Payment Allocations table
CREATE TABLE IF NOT EXISTS `inv_supplier_payment_allocations` (
 `id` varchar(50) NOT NULL,
 `payment_id` varchar(50) NOT NULL COMMENT 'Reference to the payment',
 `purchase_order_id` varchar(50) NOT NULL COMMENT 'Purchase order being allocated',
 `order_item_id` varchar(50) DEFAULT NULL COMMENT 'Specific order item this allocation covers (optional)',
 `allocated_amount` decimal(12,2) NOT NULL COMMENT 'Amount allocated to this order/item',
 `allocation_notes` text DEFAULT NULL COMMENT 'Notes about this specific allocation',
 `created_at` timestamp NULL DEFAULT current_timestamp(),
 PRIMARY KEY (`id`),
 KEY `inv_supplier_payment_allocations_payment_id_foreign` (`payment_id`),
 KEY `inv_supplier_payment_allocations_purchase_order_id_foreign` (`purchase_order_id`),
 KEY `inv_supplier_payment_allocations_order_item_id_foreign` (`order_item_id`),
 KEY `idx_allocation_payment_po` (`payment_id`,`purchase_order_id`),
 KEY `idx_payment_allocations_created_date` (`created_at`),
 CONSTRAINT `inv_supplier_payment_allocations_order_item_id_foreign` FOREIGN KEY (`order_item_id`) REFERENCES `inv_purchase_order_items` (`id`),
 CONSTRAINT `inv_supplier_payment_allocations_payment_id_foreign` FOREIGN KEY (`payment_id`) REFERENCES `inv_supplier_payments` (`id`) ON DELETE CASCADE,
 CONSTRAINT `inv_supplier_payment_allocations_purchase_order_id_foreign` FOREIGN KEY (`purchase_order_id`) REFERENCES `inv_purchase_orders` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Tracks how payments are allocated across purchase order items';

-- =====================================================
-- ACCOUNTING INTEGRATION TABLES
-- =====================================================

-- Journal Entry Lines table
CREATE TABLE IF NOT EXISTS `acc_journal_entry_lines` (
 `id` varchar(50) NOT NULL,
 `account_id` varchar(50) NOT NULL COMMENT 'Account being debited or credited',
 `debit_amount` decimal(12,2) DEFAULT 0.00 COMMENT 'Debit amount (if any)',
 `credit_amount` decimal(12,2) DEFAULT 0.00 COMMENT 'Credit amount (if any)',
 `line_description` varchar(255) DEFAULT NULL COMMENT 'Description for this specific line',
 `reference_id` varchar(50) DEFAULT NULL COMMENT 'Optional reference to specific item/transaction',
 `reference_type` varchar(50) DEFAULT NULL COMMENT 'Type of reference (order_item, payment_allocation, etc.)',
 `entry_date` date NOT NULL COMMENT 'Date of the journal line',
 `source_module` enum('inventory','billing','expense','other') DEFAULT 'inventory' COMMENT 'Which module created this entry',
 `entry_status` enum('draft','posted','reversed') DEFAULT 'draft' COMMENT 'Status of the journal line',
 `posted_by` varchar(100) DEFAULT NULL COMMENT 'User who posted this line',
 `posted_at` timestamp NULL DEFAULT NULL COMMENT 'When line was posted',
 `created_at` timestamp NULL DEFAULT current_timestamp(),
 `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
 PRIMARY KEY (`id`),
 KEY `idx_journal_line_account` (`account_id`),
 KEY `idx_journal_line_reference` (`reference_id`,`reference_type`),
 KEY `idx_journal_line_date` (`entry_date`),
 KEY `idx_journal_line_status` (`entry_status`),
 KEY `idx_journal_line_source` (`source_module`),
 KEY `idx_journal_line_posted_date` (`posted_at`),
 KEY `idx_journal_lines_created_date` (`created_at`),
 KEY `idx_journal_lines_updated_date` (`updated_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Standalone table for accounting journal lines showing account debits and credits';

-- =====================================================
-- COMMISSION MANAGEMENT TABLES
-- =====================================================

-- Commission Tracking table
CREATE TABLE IF NOT EXISTS `commission_tracking` (
 `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
 `serviceid` int(10) unsigned NOT NULL,
 `commission_percentage` decimal(5,2) NOT NULL COMMENT 'Rate applied at calculation time',
 `commission_due` decimal(10,2) NOT NULL,
 `type` enum('clinician','organization') NOT NULL,
 `recipient_id` int(10) unsigned NOT NULL COMMENT 'clinician or organization ID',
 `calculated_at` datetime NOT NULL DEFAULT current_timestamp() COMMENT 'When commission was calculated',
 `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
 `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
 PRIMARY KEY (`id`),
 UNIQUE KEY `serviceid` (`serviceid`),
 KEY `commission_tracking_serviceid_index` (`serviceid`),
 KEY `commission_tracking_type_index` (`type`),
 KEY `commission_tracking_recipient_id_index` (`recipient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Commission Batch Payments table
CREATE TABLE IF NOT EXISTS `commission_batch_payments` (
 `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
 `batch_reference` varchar(100) NOT NULL,
 `recipient_type` enum('clinician','organization') NOT NULL,
 `recipient_id` int(10) unsigned NOT NULL,
 `start_date` date NOT NULL,
 `end_date` date NOT NULL,
 `total_commission_amount` decimal(10,2) NOT NULL,
 `payment_amount` decimal(10,2) NOT NULL,
 `waived_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
 `status` enum('pending','completed','cancelled') NOT NULL DEFAULT 'pending',
 `payment_date` date DEFAULT NULL,
 `created_by` int(10) unsigned NOT NULL,
 `notes` text DEFAULT NULL,
 `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
 `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
 `payment_method` int(1) NOT NULL,
 PRIMARY KEY (`id`),
 UNIQUE KEY `batch_reference` (`batch_reference`),
 KEY `commission_batch_payments_recipient_type_recipient_id_index` (`recipient_type`,`recipient_id`),
 KEY `commission_batch_payments_status_index` (`status`),
 KEY `commission_batch_payments_created_by_index` (`created_by`),
 KEY `commission_batch_payments_start_date_end_date_index` (`start_date`,`end_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Commission Batch Payment Services table
CREATE TABLE IF NOT EXISTS `commission_batch_payment_services` (
 `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
 `batch_payment_id` int(10) unsigned NOT NULL,
 `serviceid` int(10) unsigned NOT NULL,
 `commission_due` decimal(10,2) NOT NULL,
 `amount_allocated` decimal(10,2) NOT NULL,
 `waived_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
 `status` enum('paid','partial','waived') NOT NULL,
 `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
 PRIMARY KEY (`id`),
 UNIQUE KEY `batch_svc_unique` (`batch_payment_id`,`serviceid`),
 KEY `commission_batch_payment_services_batch_payment_id_index` (`batch_payment_id`),
 KEY `commission_batch_payment_services_serviceid_index` (`serviceid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Commission Payment Transactions table
CREATE TABLE IF NOT EXISTS `commission_payment_transactions` (
 `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
 `batch_payment_service_id` int(10) unsigned NOT NULL,
 `amount_paid` decimal(10,2) NOT NULL,
 `trackid` int(10) unsigned DEFAULT NULL COMMENT 'Reference to payment tracking record',
 `paymentmode` int(10) unsigned DEFAULT NULL,
 `paid_by` int(10) unsigned DEFAULT NULL,
 `notes` text DEFAULT NULL,
 `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
 PRIMARY KEY (`id`),
 KEY `commission_payment_transactions_batch_payment_service_id_index` (`batch_payment_service_id`),
 KEY `commission_payment_transactions_trackid_index` (`trackid`),
 KEY `commission_payment_transactions_paid_by_index` (`paid_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


ALTER TABLE `companyprofile` CHANGE `ALTERNATIVENUMBER` `ALTERNATIVENUMBER` VARCHAR(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL;


ALTER TABLE `companyprofile` ADD COLUMN IF NOT EXISTS `additionalInfo` TEXT NULL AFTER `WEBSITE`;


ALTER TABLE `dboservices` ADD `nhismembershipid` INT(255) NULL DEFAULT NULL AFTER `outsourceprice`;

ALTER TABLE `dboservices` ADD `claimscheckcode` INT(25) NULL DEFAULT NULL AFTER `nhismembershipid`;


ALTER TABLE `billingstrategy` ADD `isNHIS` TINYINT(1) NULL DEFAULT 0 AFTER `updatedon`;


ALTER TABLE `backup_security_settings` ADD `storage_path` TEXT NOT NULL AFTER `updated_at`;