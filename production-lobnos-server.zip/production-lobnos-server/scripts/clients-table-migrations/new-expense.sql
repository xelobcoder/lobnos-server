CREATE TABLE IF NOT EXISTS `invoices` (
 `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
 `invoice_number` varchar(50)  NOT NULL,
 `invoice_date` datetime NOT NULL,
 `due_date` datetime DEFAULT NULL,
 `merchant_id` int(10) UNSIGNED NOT NULL,
 `employee_id` int(10) UNSIGNED NOT NULL,
 `branch_id` int(10) UNSIGNED DEFAULT NULL,
 `total_amount` decimal(12,2) NOT NULL,
 `tax_amount` decimal(12,2) DEFAULT 0.00,
 `status` enum('Pending','Approved','Rejected','Paid') DEFAULT 'Pending',
 `created_on` datetime DEFAULT current_timestamp(),
 `updated_on` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
 PRIMARY KEY (`id`),
 UNIQUE KEY `invoice_number` (`invoice_number`),
 KEY `fk_invoice_merchant` (`merchant_id`),
 KEY `fk_invoice_employee` (`employee_id`),
 CONSTRAINT `fk_invoice_employee` FOREIGN KEY (`employee_id`) REFERENCES `roles` (`employeeid`),
 CONSTRAINT `fk_invoice_merchant` FOREIGN KEY (`merchant_id`) REFERENCES `expense_merchants` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `invoice_expenses` (
 `id` int(10) UNSIGNED PRIMARY KEY NOT NULL AUTO_INCREMENT,
 `invoice_id` int(10) UNSIGNED NOT NULL,
 `expense_id` int(10) UNSIGNED NOT NULL,
 UNIQUE KEY `invoice_id` (`invoice_id`,`expense_id`),
 KEY `fk_expense` (`expense_id`),
 CONSTRAINT `fk_expense` FOREIGN KEY (`expense_id`) REFERENCES `expensesrecord` (`id`),
 CONSTRAINT `fk_invoice` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `expense_payments` (
 `id` int(10) UNSIGNED PRIMARY KEY NOT NULL AUTO_INCREMENT,
 `expense_id` int(10) UNSIGNED NOT NULL,
 `invoice_id` int(10) UNSIGNED DEFAULT NULL,
 `payment_date` datetime NOT NULL,
 `amount` decimal(12,2) NOT NULL,
 `method` varchar(50) DEFAULT NULL,
 `status` enum('Paid','Pending','Failed') DEFAULT 'Pending',
 `created_by` int(10) UNSIGNED NOT NULL,
 `created_on` datetime DEFAULT current_timestamp(),
 KEY `fk_payment_expense` (`expense_id`),
 KEY `fk_payment_invoice` (`invoice_id`),
 CONSTRAINT `fk_payment_expense` FOREIGN KEY (`expense_id`) REFERENCES `expensesrecord` (`id`),
 CONSTRAINT `fk_payment_invoice` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


