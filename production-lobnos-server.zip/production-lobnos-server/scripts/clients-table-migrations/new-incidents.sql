-- Incident Management System Database Schema
-- Generated for compliance and quality control incident tracking
-- Date: December 13, 2025

-- =====================================================
-- INCIDENT MANAGEMENT TABLES
-- =====================================================

-- Incidents table
CREATE TABLE IF NOT EXISTS `incidents` (
 `id` varchar(50) NOT NULL,
 `type` enum('patient-safety','quality','security','compliance') NOT NULL,
 `title` varchar(255) NOT NULL,
 `description` text NOT NULL,
 `severity` enum('low','medium','high','critical') NOT NULL,
 `status` enum('reported','investigating','root-cause-analysis','corrective-actions','resolved','closed') NOT NULL DEFAULT 'reported',
 `reported_at` timestamp NOT NULL DEFAULT current_timestamp(),
 `affected_parties` text DEFAULT NULL,
 `location` varchar(255) DEFAULT NULL,
 `immediate_actions` text DEFAULT NULL,
 `root_cause` text DEFAULT NULL,
 `root_cause_analysis` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`root_cause_analysis`)),
 `corrective_actions` text DEFAULT NULL,
 `corrective_action_plan` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`corrective_action_plan`)),
 `regulatory_reporting` tinyint(1) DEFAULT 0,
 `escalated_to` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`escalated_to`)),
 `follow_up_date` date DEFAULT NULL,
 `resolution_date` date DEFAULT NULL,
 `attachments` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`attachments`)),
 `investigation_notes` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`investigation_notes`)),
 `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
 `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
 `reported_by` int(10) UNSIGNED NOT NULL,
 PRIMARY KEY (`id`),
 KEY `incidents_type_index` (`type`),
 KEY `incidents_severity_index` (`severity`),
 KEY `incidents_status_index` (`status`),
 KEY `incidents_reported_at_index` (`reported_at`),
 KEY `incidents_location_index` (`location`),
     CONSTRAINT `fk_incidents_reported_by` FOREIGN KEY (`reported_by`) REFERENCES `roles` (`employeeid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Incident Audit Trail table
CREATE TABLE IF NOT EXISTS `incident_audit_trail` (
 `id` varchar(50) NOT NULL,
 `incident_id` varchar(50) NOT NULL,
 `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
 `action` varchar(100) NOT NULL,
 `employeeId` int(10) UNSIGNED NOT NULL,
 `oldValue` text DEFAULT NULL,
 `newValue` text DEFAULT NULL,
 `details` text DEFAULT NULL,
 `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
 PRIMARY KEY (`id`),
 KEY `incident_audit_trail_incident_id_index` (`incident_id`),
 KEY `incident_audit_trail_timestamp_index` (`timestamp`),
 KEY `incident_audit_trail_action_index` (`action`),
 KEY `incident_audit_trail_user_index` (`employeeId`),
 CONSTRAINT `fk_incident_audit_trail_employee` FOREIGN KEY (`employeeId`) REFERENCES `roles` (`employeeid`),
     CONSTRAINT `fk_incident_audit_trail_incident` FOREIGN KEY (`incident_id`) REFERENCES `incidents` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- USEFUL INDEXES FOR PERFORMANCE
-- =====================================================

-- Additional indexes for common queries
CREATE INDEX IF NOT EXISTS idx_incidents_type_status ON incidents(type, status);
CREATE INDEX IF NOT EXISTS idx_incidents_severity_status ON incidents(severity, status);
CREATE INDEX IF NOT EXISTS idx_incidents_reported_status ON incidents(reported_at, status);
CREATE INDEX IF NOT EXISTS idx_audit_trail_incident_timestamp ON incident_audit_trail(incident_id, timestamp);

-- =====================================================
-- ACCESS CONTROL & SECURITY TABLES
-- =====================================================

-- Access Windows table
CREATE TABLE IF NOT EXISTS `access_windows` (
 `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
 `employeeid` int(10) UNSIGNED NOT NULL,
 `category` enum('global','individual') NOT NULL DEFAULT 'individual',
 `edit_window` enum('1h','4h','8h','12h','24h','1d','1w','2w','1m') NOT NULL,
 `access_window` enum('1h','4h','8h','12h','24h','1d','1w','2w','1m') NOT NULL,
 `applicable_role` enum('scientist','phlebotomist','customer service representative','sonographer') DEFAULT NULL,
 `require_approval` tinyint(1) NOT NULL DEFAULT 0,
 `created_at` datetime NOT NULL DEFAULT current_timestamp(),
 `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
 PRIMARY KEY (`id`),
     KEY `idx_employeeid` (`employeeid`),
     CONSTRAINT `fk_access_windows_employee` FOREIGN KEY (`employeeid`) REFERENCES `roles` (`employeeid`)

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Result Access Requests table
CREATE TABLE IF NOT EXISTS `result_access_requests` (
 `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
 `patientid` int(10) UNSIGNED NOT NULL,
 `staffid` int(10) UNSIGNED NOT NULL,
 `requestType` enum('access','edit') NOT NULL,
 `requestedAt` datetime NOT NULL,
 `status` enum('pending','granted','revoked','expired') NOT NULL DEFAULT 'pending',
 `ascensionid` int(10) UNSIGNED NOT NULL,
 `grantedAt` datetime DEFAULT NULL,
 `revokedAt` datetime DEFAULT NULL,
 `expiredAt` datetime DEFAULT NULL,
 `accessedAt` datetime DEFAULT NULL,
 `reason` text DEFAULT NULL,
 `urgency` enum('low','medium','high','critical') DEFAULT NULL,
 PRIMARY KEY (`id`),
 KEY `idx_patientid` (`patientid`),
 KEY `idx_staffid` (`staffid`),
 KEY `idx_status` (`status`),
 CONSTRAINT `result_access_requests_ibfk_1` FOREIGN KEY (`patientid`) REFERENCES `new_patients` (`patientid`) ON DELETE CASCADE ON UPDATE CASCADE,
 CONSTRAINT `result_access_requests_ibfk_2` FOREIGN KEY (`staffid`) REFERENCES `roles` (`employeeid`) ON DELETE CASCADE ON UPDATE CASCADE,
     CONSTRAINT `result_access_requests_ibfk_3` FOREIGN KEY (`ascensionid`) REFERENCES `test_ascension` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- =====================================================
-- CRM & LEAD MANAGEMENT TABLES
-- =====================================================

-- Leads table
CREATE TABLE IF NOT EXISTS `leads` (
 `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Unique identifier for the lead',
 `firstname` varchar(255) NOT NULL COMMENT 'First name of the lead',
 `lastname` varchar(255) NOT NULL COMMENT 'Last name of the lead',
 `middlename` varchar(255) DEFAULT NULL COMMENT 'Middle name of the lead',
 `contact_person` varchar(255) NOT NULL COMMENT 'Primary contact person',
 `contact_email` varchar(255) NOT NULL COMMENT 'Email address (must be unique)',
 `contact_phone` varchar(50) NOT NULL COMMENT 'Phone number',
 `company_name` varchar(255) DEFAULT NULL COMMENT 'Company name (optional)',
 `industry_type` enum('healthcare','pharmaceutical','biotech','research') NOT NULL DEFAULT 'healthcare' COMMENT 'Type of industry',
 `lead_source` enum('website','referral','social_media','cold_call','trade_show') NOT NULL DEFAULT 'website' COMMENT 'Source of the lead',
 `service_interest` text DEFAULT NULL COMMENT 'Services the lead is interested in',
 `status` enum('new','contacted','qualified','proposal','negotiation','closed_won','closed_lost') NOT NULL DEFAULT 'new' COMMENT 'Current status of the lead',
 `priority` enum('low','medium','high','urgent') NOT NULL DEFAULT 'medium' COMMENT 'Priority level',
 `location` varchar(255) NOT NULL COMMENT 'Geographic location',
 `assigned_to` int(10) unsigned DEFAULT NULL COMMENT 'Assigned to user ID',
 `notes` text DEFAULT NULL COMMENT 'Additional notes',
 `created_at` timestamp NOT NULL DEFAULT current_timestamp() COMMENT 'Record creation timestamp',
 `updated_at` timestamp NOT NULL DEFAULT current_timestamp() COMMENT 'Last update timestamp',
 `created_by` int(10) unsigned DEFAULT NULL COMMENT 'Created by user ID',
 PRIMARY KEY (`id`),
 UNIQUE KEY `contact_email` (`contact_email`),
 KEY `idx_lead_email` (`contact_email`),
 KEY `idx_lead_status` (`status`),
 KEY `idx_lead_priority` (`priority`),
 KEY `idx_lead_assigned_to` (`assigned_to`),
 KEY `idx_lead_created_at` (`created_at`),
 CONSTRAINT `fk_leads_assigned_to` FOREIGN KEY (`assigned_to`) REFERENCES `roles` (`employeeid`),
 CONSTRAINT `fk_leads_created_by` FOREIGN KEY (`created_by`) REFERENCES `roles` (`employeeid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- =====================================================
-- BACKUP & SECURITY TABLES
-- =====================================================

-- Backup Schedules table
CREATE TABLE IF NOT EXISTS `backup_schedules` (
 `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
 `schedule_name` varchar(255) NOT NULL,
 `frequency` enum('daily','weekly','monthly','hourly') NOT NULL,
 `backup_time` time NOT NULL,
 `retention_days` int(11) NOT NULL,
 `employeeid` int(10) UNSIGNED NOT NULL,
 `backup_path` varchar(255) DEFAULT NULL,
 `backup_type` enum('database','files','full_system') NOT NULL,
 `is_active` tinyint(1) NOT NULL DEFAULT 1,
 `database_name` varchar(255) DEFAULT NULL,
 `source_path` varchar(255) DEFAULT NULL,
 `last_run` timestamp NULL DEFAULT NULL,
 `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
 `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
 PRIMARY KEY (`id`),
 KEY `employeeid` (`employeeid`),
 CONSTRAINT `backup_schedules_ibfk_1` FOREIGN KEY (`employeeid`) REFERENCES `roles` (`employeeid`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Backup Logs table
CREATE TABLE IF NOT EXISTS `backup_logs` (
 `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
 `backup_name` varchar(255) NOT NULL,
 `is_successful` tinyint(1) NOT NULL DEFAULT 0,
 `is_full_backup` tinyint(1) NOT NULL DEFAULT 0,
 `backup_size_bytes` bigint(20) DEFAULT NULL,
 `backup_type` enum('database','files','full_system') NOT NULL,
 `backup_mode` enum('automated','manual') NOT NULL,
 `backup_date` datetime NOT NULL DEFAULT current_timestamp(),
 `backup_path` varchar(255) DEFAULT NULL,
 `error_message` text DEFAULT NULL,
 `duration_seconds` int(11) DEFAULT NULL,
 `created_by` INT(10) UNSIGNED DEFAULT NULL,
 `schedule_id` int(10) UNSIGNED DEFAULT NULL,
 `encryption_key_id` varchar(255) DEFAULT NULL,
 `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
 `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
 PRIMARY KEY (`id`),
 KEY `schedule_id` (`schedule_id`),
 CONSTRAINT `backup_logs_ibfk_1` FOREIGN KEY (`schedule_id`) REFERENCES `backup_schedules` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Backup Security Settings table
CREATE TABLE IF NOT EXISTS `backup_security_settings` (
 `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
 `encryption_enabled` tinyint(1) NOT NULL DEFAULT 0,
 `encryption_algorithm` varchar(255) NOT NULL DEFAULT 'AES-256',
 `key_rotation_days` int(11) NOT NULL DEFAULT 90,
 `secure_deletion_enabled` tinyint(1) NOT NULL DEFAULT 0,
 `deletion_passes` int(11) NOT NULL DEFAULT 1,
 `current_key_id` varchar(255) DEFAULT NULL,
 `key_last_rotated` date DEFAULT NULL,
 `is_active` tinyint(1) NOT NULL DEFAULT 1,
 `created_at` timestamp NULL DEFAULT NULL,
 `updated_at` timestamp NULL DEFAULT NULL,
 PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Encryption Keys table
CREATE TABLE IF NOT EXISTS `encryption_keys` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `key_id` varchar(255) NOT NULL,
 `encrypted_key` text NOT NULL,
 `algorithm` varchar(255) NOT NULL DEFAULT 'aes-256-cbc',
 `expires_at` date DEFAULT NULL,
 `is_active` tinyint(1) NOT NULL DEFAULT 1,
 `deactivated_at` date DEFAULT NULL,
 `created_by` INT(10) UNSIGNED DEFAULT NULL,
 `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
 `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
 PRIMARY KEY (`id`),
 UNIQUE KEY `key_id` (`key_id`),
 KEY `idx_encryption_keys_key_id` (`key_id`),
 KEY `idx_encryption_keys_active` (`is_active`),

 CONSTRAINT `fk_encryption_keys_created_by` FOREIGN KEY (`created_by`) REFERENCES `roles` (`employeeid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- Lead Follow-ups table
CREATE TABLE IF NOT EXISTS `lead_followups` (
 `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Unique identifier for the follow-up',
 `lead_id` int(10) UNSIGNED NOT NULL COMMENT 'Foreign key to leads table',
 `followup_type` enum('call','email','meeting','visit','other') NOT NULL DEFAULT 'call' COMMENT 'Type of follow-up',
 `followup_date` date DEFAULT NULL COMMENT 'Date of the follow-up',
 `notes` text NOT NULL COMMENT 'Notes for the follow-up',
 `next_followup_date` date DEFAULT NULL COMMENT 'Date for next follow-up',
 `priority` enum('low','medium','high','urgent') NOT NULL DEFAULT 'medium' COMMENT 'Priority level',
 `status` enum('pending','completed','cancelled') NOT NULL DEFAULT 'pending' COMMENT 'Status of the follow-up',
 `created_by` int(10) UNSIGNED DEFAULT NULL COMMENT 'User who created the follow-up',
 `created_at` timestamp NOT NULL DEFAULT current_timestamp() COMMENT 'Record creation timestamp',
 `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp() COMMENT 'Last update timestamp',
 PRIMARY KEY (`id`),
 KEY `idx_lead_id` (`lead_id`),
 KEY `idx_followup_date` (`followup_date`),
 KEY `idx_next_followup_date` (`next_followup_date`),
 KEY `idx_status` (`status`),
 KEY `idx_priority` (`priority`),
 KEY `idx_created_by` (`created_by`),
 CONSTRAINT `fk_lead_followups_leads` FOREIGN KEY (`lead_id`) REFERENCES `leads` (`id`),
 CONSTRAINT `fk_lead_followups_created_by` FOREIGN KEY (`created_by`) REFERENCES `roles` (`employeeid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



ALTER TABLE `test_ascension` ADD INDEX(`collectionStartDate`, `collectionEndDate`);
ALTER TABLE `test_ascension` ADD INDEX(`processingStartDate`, `processingEndDate`);
ALTER TABLE `test_ascension` ADD INDEX(`resultEntryStart`, `resultEntryEnd`);
ALTER TABLE `test_ascension` ADD INDEX(`collectionStartDate`, `resultEntryEnd`);
ALTER TABLE `test_ascension` ADD INDEX(`ascension_date`, `resultEntryEnd`);

ALTER TABLE `test_ascension` ADD INDEX(`billingid`);
ALTER TABLE `test_ascension` ADD INDEX(`serviceid`);
ALTER TABLE `test_ascension` ADD INDEX(`testid`);
ALTER TABLE `test_ascension` ADD INDEX(`ascension_date`);
ALTER TABLE `dbotestresultapproval` ADD INDEX(`ascensionid`);
ALTER TABLE `dbotestresultapproval` ADD INDEX(`isapproved`);
ALTER TABLE billing
ADD INDEX idx_billing_patient_outstanding (patientid, outstanding);
ALTER TABLE `dboservices` ADD INDEX(`serviceCategory`);
ALTER TABLE `dboservices` ADD INDEX(`status`);
ALTER TABLE `dboservices` ADD INDEX(`registrationType`);
ALTER TABLE `dboservices` ADD INDEX(`isoutsourced`);
ALTER TABLE `dboservices` ADD INDEX dbo_services_added (`serviceAddedOn`);
ALTER TABLE `dboservices` ADD INDEX(`serviceCategory`, `clinicianId`);
ALTER TABLE `dboservices` ADD INDEX(`serviceCategory`, `organizationId`);
ALTER TABLE `dboservices` ADD INDEX(`outsourceid`);


ALTER TABLE `test_results` ADD INDEX(`ascensionid`);
ALTER TABLE `test_results` ADD INDEX(`billingid`);
ALTER TABLE `test_results` ADD INDEX(`testid`);
ALTER TABLE `test_results` ADD INDEX(`patientid`);
ALTER TABLE `test_results` ADD INDEX(`created_on`);
ALTER TABLE `test_results` ADD INDEX(`patientid`, `testid`);
ALTER TABLE `test_results` ADD INDEX(`billingid`, `patientid`, `testid`);
ALTER TABLE `test_results` ADD INDEX(`testid`, `created_on`, `fieldid`);


ALTER TABLE `new_patients` ADD INDEX(`date`);
ALTER TABLE `new_patients` ADD INDEX(`mobile_number`);
ALTER TABLE `new_patients` ADD INDEX(`email`);
ALTER TABLE `new_patients` ADD INDEX(`email`, `mobile_number`);

ALTER TABLE `dbobillingrefundtable` ADD INDEX(`serviceid`);
ALTER TABLE `dbobillingrefundtable` ADD INDEX(`isRefundCompleted`);
ALTER TABLE `dbobillingrefundtable` ADD INDEX(`isRefundInitiated`);
ALTER TABLE `dbobillingrefundtable` ADD INDEX(`isRefundApproved`);
ALTER TABLE `dbobillingrefundtable` ADD INDEX(`isRefundMatterClosed`);
ALTER TABLE `dbobillingrefundtable` ADD INDEX(`approvalDate`);





ALTER TABLE inv_supplier_payments
ADD COLUMN expense_synced TINYINT(1) DEFAULT 0,
ADD COLUMN expense_id VARCHAR(255) NULL,
ADD COLUMN expense_invoice_id VARCHAR(255) NULL;
