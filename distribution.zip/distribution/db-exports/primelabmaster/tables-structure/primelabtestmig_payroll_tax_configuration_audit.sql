-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: localhost    Database: primelabtestmig
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `payroll_tax_configuration_audit`
--

DROP TABLE IF EXISTS `payroll_tax_configuration_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payroll_tax_configuration_audit` (
  `audit_id` int unsigned NOT NULL AUTO_INCREMENT,
  `tax_config_id` int unsigned NOT NULL,
  `tax_year` varchar(4) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `country` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Ghana',
  `tax_bands` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `standard_exemption` decimal(10,2) DEFAULT '0.00',
  `dependent_relief` decimal(10,2) DEFAULT '0.00',
  `disability_exemption` decimal(10,2) DEFAULT '0.00',
  `employee_ssnit_rate` decimal(5,2) DEFAULT '5.50',
  `employer_ssnit_rate` decimal(5,2) DEFAULT '13.00',
  `tier3_employee_rate` decimal(5,2) DEFAULT '5.00',
  `tier3_employer_rate` decimal(5,2) DEFAULT '5.00',
  `ssnit_ceiling` decimal(10,2) DEFAULT NULL,
  `pension_ceiling` decimal(10,2) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `operation_type` enum('INSERT','UPDATE','DELETE') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `operation_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `operation_user` int unsigned DEFAULT NULL,
  `operation_user_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`audit_id`),
  KEY `idx_tax_config_id` (`tax_config_id`),
  KEY `idx_operation_type` (`operation_type`),
  KEY `idx_operation_timestamp` (`operation_timestamp`),
  KEY `idx_operation_user` (`operation_user`),
  CONSTRAINT `payroll_tax_configuration_audit_ibfk_1` FOREIGN KEY (`tax_config_id`) REFERENCES `payroll_tax_configuration` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `payroll_tax_configuration_audit_ibfk_2` FOREIGN KEY (`operation_user`) REFERENCES `roles` (`employeeid`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `payroll_tax_configuration_audit_chk_1` CHECK (json_valid(`tax_bands`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-10-09 16:00:34
