'use client';
import Link from 'next/link';
import { FormEvent, useCallback, useEffect, useRef, useState } from 'react';
import { customFetch } from '../../../components/Auth/customFetch';
import { useApplication } from '../../../components/Auth/useApplicationContext';
import PharmacyPaymentFields,{usePharmacyDocument,usePharmacyPayment} from '../components/PharmacyPaymentFields';
import { printPharmacyReceipt } from '../../../lib/pharmacy/receipt';
import styles from './pos.module.css';

type PriceType='retail'|'wholesale';
type Medicine={inventoryItemId:string;name:string;sku:string;salePrice:number;wholesalePrice?:number;availableStock:number;dispensableStock?:number;requiresPrescription?:boolean};
type Line=Medicine&{quantity:number};
const money=(value:number)=>'GHS '+Number(value).toFixed(2);
const unitPrice=(item:Medicine,type:PriceType)=>Number(type==='wholesale'?item.wholesalePrice||0:item.salePrice);
const lineTotal=(item:Line,type:PriceType)=>Math.round(Math.round(unitPrice(item,type)*100)*Math.round(item.quantity*1000)/1000)/100;
export default function PharmacySellPage(){
     const app=useApplication() as any,payment=usePharmacyPayment('pos'),suspension=usePharmacyDocument('pos-suspend');
     const [search,setSearch]=useState(''),[items,setItems]=useState<Medicine[]>([]),[cart,setCart]=useState<Line[]>([]),[priceType,setPriceType]=useState<PriceType>('retail');
     const [customer,setCustomer]=useState(''),[method,setMethod]=useState('cash'),[error,setError]=useState(''),[notice,setNotice]=useState(''),[busy,setBusy]=useState(false);
     const [receipt,setReceipt]=useState<any>(null),[held,setHeld]=useState<any[]>([]),[heldId,setHeldId]=useState<string|null>(null),[showHeld,setShowHeld]=useState(false),[loading,setLoading]=useState(false),[active,setActive]=useState(0);
     const searchInput=useRef<HTMLInputElement>(null),payPanel=useRef<HTMLDivElement>(null),generation=useRef(0),resultsFor=useRef(''),busyRef=useRef(false);
     const locked=busy||!!payment.pending||!!suspension.pending,total=cart.reduce((sum,line)=>sum+Math.round(lineTotal(line,priceType)*100),0)/100;
     const focusSearch=()=>requestAnimationFrame(()=>searchInput.current?.focus());
     const loadHeld=useCallback(async()=>{const r=await customFetch('pharmacy/sales/held?count=100');if(!r?.success)throw new Error(r?.error?.message||'Unable to load suspended sales');setHeld(r.data.sales||[]);},[]);
     useEffect(()=>{loadHeld().catch(e=>setError(e.message));},[loadHeld]);
     const lookup=useCallback(async(term:string)=>{
          const token=++generation.current;if(!term.trim()){setItems([]);setLoading(false);resultsFor.current='';return [];}
          setLoading(true);
          try{const r=await customFetch('pharmacy/catalogue?sellableOnly=true&count=20&search='+encodeURIComponent(term.trim()));if(!r?.success)throw new Error(r?.error?.message||'Unable to search medicines');if(token!==generation.current)return [];
               const rows:Medicine[]=r.data.items||[];setItems(rows);resultsFor.current=term.trim();setActive(0);return rows;
          }catch(e){if(token===generation.current){setItems([]);setError(e instanceof Error?e.message:'Medicine search failed');}return [];}finally{if(token===generation.current)setLoading(false);}
     },[]);
     useEffect(()=>{const timer=setTimeout(()=>lookup(search),140);return()=>{clearTimeout(timer);generation.current++;};},[search,lookup]);
     const add=(item:Medicine)=>{
          if(locked)return;
          if(item.requiresPrescription){setError('This medicine requires a prescription. Dispense it from the prescription queue.');return;}
          if(unitPrice(item,priceType)<=0){setError('Configure a '+priceType+' price for '+item.name+' before selling it.');return;}
          const existing=cart.find(line=>line.inventoryItemId===item.inventoryItemId),next=Math.round(((existing?.quantity||0)+1)*1000)/1000,available=item.dispensableStock??item.availableStock;
          if(next>available){setError('Only '+available+' unexpired units of '+item.name+' are available.');return;}
          setCart(rows=>existing?rows.map(line=>line.inventoryItemId===item.inventoryItemId?{...line,...item,quantity:next}:line):[...rows,{...item,quantity:1}]);
          setError('');setNotice(item.name+' added');setReceipt(null);payment.setAmount('');setSearch('');setItems([]);generation.current++;focusSearch();
     };
     const setQuantity=(id:string,value:number)=>{
          if(locked||!Number.isFinite(value))return;
          if(value<=0){setCart(rows=>rows.filter(line=>line.inventoryItemId!==id));payment.setAmount('');return;}
          const line=cart.find(line=>line.inventoryItemId===id);if(!line)return;
          if(value>(line.dispensableStock??line.availableStock)){setError('Insufficient unexpired stock for '+line.name+'. Refresh or reduce the quantity.');return;}
          setCart(rows=>rows.map(row=>row.inventoryItemId===id?{...row,quantity:Math.round(value*1000)/1000}:row));payment.setAmount('');setError('');
     };
     const choosePrice=(type:PriceType)=>{
          if(locked||type===priceType)return;
          const missing=cart.filter(item=>unitPrice(item,type)<=0);if(missing.length){setError('Set a '+type+' price for '+missing.map(item=>item.name).join(', ')+' before changing this transaction.');return;}
          setPriceType(type);payment.setAmount('');setError('');setNotice('All items now use '+type+' prices.');focusSearch();
     };
     const clear=()=>{if(locked)return;if(cart.length&&!window.confirm('Clear the current basket? A recalled suspended sale will remain saved.'))return;setCart([]);setHeldId(null);setCustomer('');setSearch('');payment.setAmount('');setError('');focusSearch();};
     const checkout=async(event?:FormEvent)=>{
          event?.preventDefault();if(busyRef.current||suspension.pending||(!cart.length&&!payment.pending))return;
          busyRef.current=true;setBusy(true);setError('');
          try{const r=await payment.execute(heldId?'pharmacy/sales/held/'+heldId+'/complete':'pharmacy/sales',{priceType,customerName:customer||'Walk-in customer',paymentMethod:method,expectedTotal:total,lines:cart.map(line=>({inventoryItemId:line.inventoryItemId,quantity:line.quantity,priceType}))});if(!r?.success)throw new Error(r?.error?.message||'Checkout needs confirmation. Retry the original request.');
               setReceipt(r.data);setCart([]);setHeldId(null);setCustomer('');setSearch('');payment.setAmount('');payment.setReference('');setNotice('Sale completed. Your saved receipt is ready to print.');await loadHeld();focusSearch();
          }catch(e){setError(e instanceof Error?e.message:'Unable to confirm checkout');}finally{busyRef.current=false;setBusy(false);}
     };
     const suspend=async()=>{
          if(busyRef.current||payment.pending||(!cart.length&&!suspension.pending))return;busyRef.current=true;setBusy(true);setError('');
          try{const r=await suspension.execute('pharmacy/sales/held',{heldSaleId:heldId||undefined,priceType,customerName:customer||'Walk-in customer',lines:cart.map(line=>({inventoryItemId:line.inventoryItemId,quantity:line.quantity,priceType}))});if(!r?.success)throw new Error(r?.error?.message||'Suspension needs confirmation. Retry the original request.');
               setCart([]);setCustomer('');setHeldId(null);setSearch('');payment.setAmount('');payment.setReference('');setNotice('Sale suspended. Stock and payment have not been deducted.');await loadHeld();focusSearch();
          }catch(e){setError(e instanceof Error?e.message:'Unable to suspend sale');}finally{busyRef.current=false;setBusy(false);}
     };
     const recall=async(id:string)=>{
          if(locked||busyRef.current)return;if(cart.length&&!window.confirm('Replace this basket? Unsaved changes will be lost.'))return;busyRef.current=true;setBusy(true);setError('');
          try{const r=await customFetch('pharmacy/sales/held/'+id);if(!r?.success)throw new Error(r?.error?.message||'Suspended sale unavailable');
               const types=new Set(r.data.lines.map((line:any)=>line.priceType||'retail'));if(types.size!==1)throw new Error('This older suspended sale contains mixed prices. Review it before checkout.');const type=Array.from(types)[0] as PriceType;
               setPriceType(type);setCart(r.data.lines.map((line:any)=>({...line,salePrice:line.retailPrice??(type==='retail'?line.unitPrice:0),wholesalePrice:line.wholesalePrice??(type==='wholesale'?line.unitPrice:0),availableStock:line.availableStock??line.quantity,dispensableStock:line.dispensableStock,quantity:Number(line.quantity)})));setCustomer(r.data.customerName);setHeldId(id);setReceipt(null);setShowHeld(false);payment.setAmount('');setNotice('Suspended sale recalled. Current prices and stock are checked before checkout.');focusSearch();
          }catch(e){setError(e instanceof Error?e.message:'Unable to recall sale');}finally{busyRef.current=false;setBusy(false);}
     };
     const print=()=>{if(!receipt)return;try{printPharmacyReceipt(receipt,{name:typeof app?.company==='string'?app.company:app?.company?.name||'PHARMACY',address:app?.company?.address,phone:app?.company?.phonenumber,printedBy:app?.user?.username});}catch(e){setError(e instanceof Error?e.message:'Unable to print receipt');}};
     useEffect(()=>{const keys=(event:KeyboardEvent)=>{if(event.key==='F2'){event.preventDefault();focusSearch();}else if(event.key==='F4'){event.preventDefault();payPanel.current?.querySelector<HTMLInputElement>('input[type="number"]')?.focus();}else if(event.key==='F8'){event.preventDefault();if(!locked)suspend();}else if(event.key==='F9'){event.preventDefault();if(!locked)(document.getElementById('pharmacy-checkout') as HTMLFormElement)?.requestSubmit();}};window.addEventListener('keydown',keys);return()=>window.removeEventListener('keydown',keys);});
     return <main className={styles.page}>
          <header className={styles.header}><div><span className={styles.eyebrow}>PHARMACY · POINT OF SALE</span><h1>Checkout</h1></div><nav className={styles.actions}><Link href="/pharmacy/cashier">Cashier & shift</Link><Link href="/pharmacy/prescriptions">Prescriptions</Link><button className="btn btn-outline-secondary" disabled={locked} onClick={()=>{setShowHeld(!showHeld);loadHeld().catch(e=>setError(e.message));}}>Suspended sales <span className="badge text-bg-secondary">{held.length}</span></button></nav></header>
          {error&&<div className="alert alert-danger" role="alert">{error}</div>}<div className={styles.notice} role="status" aria-live="polite">{notice}</div>
          {payment.pending&&<div className="alert alert-warning">Payment confirmation is pending. <button className="btn btn-warning" disabled={busy} onClick={()=>checkout()}>Retry original checkout</button></div>}
          {suspension.pending&&<div className="alert alert-warning">Sale suspension needs confirmation. <button className="btn btn-warning" disabled={busy} onClick={suspend}>Retry original suspension</button></div>}
          {showHeld&&<section className={styles.suspended}><h2>Suspended sales</h2>{held.length?<div className={styles.heldList}>{held.map(sale=><button key={sale.id} disabled={locked} onClick={()=>recall(sale.id)}><strong>{sale.customerName}</strong><span>{money(sale.total)}</span><small>{new Date(sale.createdAt).toLocaleString('en-GH')} · {sale.lines?.length||0} item(s)</small></button>)}</div>:<p>No suspended sales.</p>}</section>}
          <form id="pharmacy-checkout" onSubmit={checkout} className={styles.layout}>
               <section className={styles.basket}>
                    <div className={styles.searchArea}><div className={styles.transaction}><div><h2>Current sale {heldId&&<span className="badge text-bg-info">Recalled</span>}</h2><p>One price basis applies to every item in this transaction.</p></div><div className={styles.priceSwitch} role="group" aria-label="Transaction pricing">{(['retail','wholesale'] as PriceType[]).map(type=><button type="button" key={type} aria-pressed={priceType===type} className={priceType===type?styles.selected:''} disabled={locked} onClick={()=>choosePrice(type)}>{type==='retail'?'Retail':'Wholesale'}</button>)}</div></div>
                         <label htmlFor="medicine-search" className={styles.searchLabel}>Search medicine or scan barcode <kbd>F2</kbd></label>
                         <div className={styles.searchBox}><input ref={searchInput} id="medicine-search" autoFocus autoComplete="off" role="combobox" aria-expanded={!!search.trim()} aria-controls="medicine-options" aria-activedescendant={items[active]?'medicine-option-'+active:undefined} placeholder="Start typing a name or scan SKU, then press Enter" value={search} disabled={locked} onChange={event=>{setSearch(event.target.value);setItems([]);}} onKeyDown={async event=>{if(event.key==='Escape'){setSearch('');setItems([]);}if(event.key==='ArrowDown'||event.key==='ArrowUp'){event.preventDefault();setActive(value=>Math.max(0,Math.min(items.length-1,value+(event.key==='ArrowDown'?1:-1))));}if(event.key==='Enter'){event.preventDefault();const term=search.trim();if(!term)return;const rows=resultsFor.current===term?items:await lookup(term);const exact=rows.find(item=>item.sku.toLowerCase()===term.toLowerCase());const item=exact||rows[active]||rows[0];if(item)add(item);}}}/>
                              {search.trim()&&<div id="medicine-options" role="listbox" className={styles.results}>{loading?<p>Searching…</p>:items.length?items.map((item,index)=><button type="button" role="option" aria-selected={active===index} id={'medicine-option-'+index} key={item.inventoryItemId} className={active===index?styles.highlight:''} disabled={locked} onMouseEnter={()=>setActive(index)} onClick={()=>add(item)}><span><strong>{item.name}</strong><small>{item.sku} · {item.dispensableStock??item.availableStock} available{item.requiresPrescription?' · Prescription required':''}</small></span><span>{unitPrice(item,priceType)>0?money(unitPrice(item,priceType)):'Price not set'} <b>＋</b></span></button>):<p>No medicines found. Try another name or SKU.</p>}</div>}
                         </div>
                    </div>
                    <div className={styles.cartHeading}><h2>Basket <span>{cart.length} item(s)</span></h2><button type="button" className="btn btn-sm btn-outline-secondary" disabled={locked||!cart.length} onClick={clear}>Clear basket</button></div>
                    {cart.length?<div className={styles.tableWrap}><table className={styles.table}><thead><tr><th>Medicine</th><th>Quantity</th><th>Unit price</th><th>Total</th><th/></tr></thead><tbody>{cart.map(line=><tr key={line.inventoryItemId}><td><strong>{line.name}</strong><small>{line.sku}</small></td><td><div className={styles.quantity}><button type="button" disabled={locked} aria-label={'Decrease '+line.name} onClick={()=>setQuantity(line.inventoryItemId,line.quantity-1)}>−</button><input aria-label={'Quantity for '+line.name} type="number" min="0.001" step="0.001" required value={line.quantity} disabled={locked} onChange={event=>setQuantity(line.inventoryItemId,Number(event.target.value))}/><button type="button" disabled={locked} aria-label={'Increase '+line.name} onClick={()=>setQuantity(line.inventoryItemId,line.quantity+1)}>+</button></div></td><td>{money(unitPrice(line,priceType))}</td><td><strong>{money(lineTotal(line,priceType))}</strong></td><td><button type="button" className={styles.remove} disabled={locked} aria-label={'Remove '+line.name} onClick={()=>setQuantity(line.inventoryItemId,0)}>×</button></td></tr>)}</tbody></table></div>:<div className={styles.empty}><span>＋</span><h3>Ready for your next customer</h3><p>Search or scan a medicine above. Added items stay here while you continue scanning.</p></div>}
                    <footer className={styles.basketFooter}><button type="button" className="btn btn-outline-primary" disabled={locked||!cart.length} onClick={suspend}>Suspend sale <kbd>F8</kbd></button><span>{priceType==='retail'?'Retail':'Wholesale'} transaction · {cart.reduce((sum,line)=>sum+line.quantity,0)} unit(s)</span></footer>
               </section>
               <aside className={styles.payment} ref={payPanel}><h2>Collect payment</h2><div className={styles.total}><span>Total due</span><strong>{money(total)}</strong></div><label className="form-label d-block">Customer (optional)<input className="form-control" maxLength={255} disabled={locked} value={customer} onChange={event=>setCustomer(event.target.value)} placeholder="Walk-in customer"/></label><label className="form-label d-block">Payment method<select className="form-select" value={method} disabled={locked} onChange={event=>{setMethod(event.target.value);payment.setAmount('');}}><option value="cash">Cash</option><option value="mobile_money">Mobile money</option><option value="card">Card</option></select></label><PharmacyPaymentFields payment={payment} method={method} total={total} disabled={locked}/><button type="button" className="btn btn-outline-secondary w-100 mb-2" disabled={locked||!cart.length} onClick={()=>payment.setAmount(total.toFixed(2))}>Exact amount</button><button type="submit" className="btn btn-success btn-lg w-100" disabled={locked||!cart.length||!payment.setup?.shift||payment.setup?.day?.status!=='open'||!payment.setup?.routes?.some((route:any)=>route.method===method)}>{busy?'Processing…':'Complete sale'} <kbd>F9</kbd></button><p className={styles.shortcut}>F2 search · F4 amount · F8 suspend · F9 pay</p></aside>
          </form>
          {receipt&&<section className={styles.receipt}><div><span className="badge text-bg-success mb-2">Payment recorded</span><h2>Receipt {receipt.receiptNumber}</h2><p>{receipt.customerName} · {new Date(receipt.completedAt).toLocaleString('en-GH')}</p><strong>{money(receipt.total)}</strong><p>Received {money(receipt.amountTendered||receipt.total)} · Change {money(receipt.change||0)}</p></div><div className={styles.actions}><button type="button" className="btn btn-primary btn-lg" onClick={print}>Print 80 mm receipt</button><button type="button" className="btn btn-outline-secondary" onClick={()=>{setReceipt(null);focusSearch();}}>Next customer</button></div></section>}
     </main>;
}
