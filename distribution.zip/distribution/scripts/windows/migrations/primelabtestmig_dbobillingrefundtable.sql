CREATE DATABASE  IF NOT EXISTS `primelabtestmig` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `primelabtestmig`;
-- MySQL dump 10.13  Distrib 8.0.45, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: primelabtestmig
-- ------------------------------------------------------
-- Server version	8.0.45

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `dbobillingrefundtable`
--

DROP TABLE IF EXISTS `dbobillingrefundtable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dbobillingrefundtable` (
  `refundid` int unsigned NOT NULL AUTO_INCREMENT,
  `serviceid` int unsigned NOT NULL,
  `refundedBy` int unsigned NOT NULL,
  `firstWitness` int unsigned NOT NULL,
  `secondWitness` int unsigned NOT NULL,
  `thirdWitness` int unsigned NOT NULL,
  `firstWitnessPurpose` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `firstWitnessDate` datetime(6) DEFAULT NULL,
  `secondWitnessDate` datetime(6) DEFAULT NULL,
  `thirdWitnessDate` datetime(6) DEFAULT NULL,
  `isRefundCompleted` int unsigned NOT NULL DEFAULT '0',
  `isRefundInitiated` tinyint(1) NOT NULL DEFAULT '0',
  `initiatedBy` int unsigned DEFAULT NULL,
  `secondWitnessPurpose` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `thirdWitnessPurpose` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `isRefundApproved` tinyint(1) NOT NULL DEFAULT '0',
  `approvalDate` tinyint(1) NOT NULL DEFAULT '0',
  `approvedby` int unsigned DEFAULT NULL,
  `amountRefunded` decimal(10,2) NOT NULL DEFAULT '0.00',
  `isRefundMatterClosed` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`refundid`),
  KEY `serviceid` (`serviceid`),
  KEY `isRefundCompleted` (`isRefundCompleted`),
  KEY `isRefundInitiated` (`isRefundInitiated`),
  KEY `isRefundApproved` (`isRefundApproved`),
  KEY `isRefundMatterClosed` (`isRefundMatterClosed`),
  KEY `approvalDate` (`approvalDate`)
) ENGINE=InnoDB AUTO_INCREMENT=9318 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-05-03  5:00:01
